function varargout = zuoye(varargin)
% ZUOYE MATLAB code for zuoye.fig
%      ZUOYE, by itself, creates a new ZUOYE or raises the existing
%      singleton*.
%
%      H = ZUOYE returns the handle to a new ZUOYE or the handle to
%      the existing singleton*.
%
%      ZUOYE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ZUOYE.M with the given input arguments.
%
%      ZUOYE('Property','Value',...) creates a new ZUOYE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before zuoye_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to zuoye_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help zuoye

% Last Modified by GUIDE v2.5 31-May-2020 22:22:15

% Begin initialization code - DO NOT EDIT

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @zuoye_OpeningFcn, ...
                   'gui_OutputFcn',  @zuoye_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before zuoye is made visible.
function zuoye_OpeningFcn(hObject, eventdata, handles, varargin)
set(handles.pushbutton1,'tooltipstring','ѡ��ģ���ԭʼ���ݱ���');
set(handles.pushbutton5,'tooltipstring','ѡ��洢���������ļ���');
set(handles.edit5,'tooltipstring','���������ڼ�����Ĭ��Ϊ4');
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to zuoye (see VARARGIN)

% Choose default command line output for zuoye
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes zuoye wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = zuoye_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
[filename,pathname]=uigetfile('.xlsx','��ѡ���ļ�');
fpath=[pathname filename];
fpathx=get(handles.edit3,'String');
if sum(fpath)~=0
    set(handles.edit3,'string',fpath);
elseif sum(fpath)==0&&sum(fpathx)==0
    msgbox('δѡ��ԭʼ�����ļ���');
end
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)

fpath=get(handles.edit2,'String');
fpath1=get(handles.edit3,'String');
date=datestr(now,31);
if sum(fpath)==0&&sum(fpath1)~=0
    msgbox('δѡ��洢���������ļ��У�');
elseif sum(fpath1)==0&&sum(fpath)~=0
    msgbox('δѡ��ԭʼ�����ļ���');
elseif sum(fpath)+sum(fpath1)==0
    msgbox('δѡ��ԭʼ�����ļ��ʹ洢���������ļ��У�');
else
    a=xlsread(fpath1,'��ϵͳ��ˮ����');
    a1=xlsread(fpath1,'����ϵͳ����ˮ����');
    a2=xlsread(fpath1,'������');
    [~,lie]=size(a);
    cyji=get(handles.edit4,'String');
    cyji=str2double(cyji);
    if cyji>(lie-1)
        msgbox('��������������ã�');
    else
        jisuan(a,a1,a2,cyji,date,fpath);
    end
end

% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)

% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
close all

% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)

pathname1=uigetdir('*.*','��ѡ���ļ���');
fpath1=pathname1;
fpathx=get(handles.edit2,'String');
if sum(fpath1)~=0
    set(handles.edit2,'string',fpath1);
elseif sum(fpath1)==0&&sum(fpathx)==0
    msgbox('δѡ��洢���������ļ��У�');
end

% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function text2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)

fpath=get(handles.edit2,'String');
fpath1=get(handles.edit3,'String');
date=datestr(now,31);
if sum(fpath)==0&&sum(fpath1)~=0
    msgbox('δѡ��洢���������ļ��У�');
elseif sum(fpath1)==0&&sum(fpath)~=0
    msgbox('δѡ��ԭʼ�����ļ���');
elseif sum(fpath)+sum(fpath1)==0
    msgbox('δѡ��ԭʼ�����ļ��ʹ洢���������ļ��У�');
else
    a=xlsread(fpath1,'��ϵͳ��ˮ����');
    a1=xlsread(fpath1,'����ϵͳ����ˮ����');
    a2=xlsread(fpath1,'������');
    [~,lie]=size(a);
    cyji=get(handles.edit4,'String');
    cyji=str2double(cyji);
    if cyji>(lie-1)
        msgbox('��������������ã�');
    else
        sjxtjisuan(a,a1,a2,cyji,date,fpath);
    end
end

% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
